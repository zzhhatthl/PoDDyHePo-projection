#' Synthetic data for model selection
#' 
#' @docType data
#' @name testdata
#' 
#' 
#' 
NULL



# NOT RUN
# colnames(testdata) <- c("year", "sex", "age", "obe", "smo", "highbp", "edulv", "marsta", "area", "dbt", "sed", "highkol")
# save(testdata, file = "testdata.rda", compress = "xz")

"testdata"

