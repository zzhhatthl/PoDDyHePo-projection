#' Synthetic data for model selection
#' 
#' @docType data
#' @name testdata
#' 
#' 
#' 
NULL

# NOT RUN
# save(testdata, file = "./data/testdata.rda", compress = "xz")

"testdata"

